import React, { Component } from 'react';

class Introduction extends Component {
  render() {
    return (
      <div className="introduction">
        <div className="introduction__content">
          <h2 className="introduction__name">
            JAY CHEN
          </h2>
          <div className="introduction__tagline">
            Full Stack Software Engineer
          </div>
          <div className="introduction__location">
            San Francisco, California
          </div>
          <div className="introduction__icons">
            <a href={personalInfo.github}><i className="fa fa-github icon"></i></a>
            <a href={personalInfo.linkedIn}><i className="fa fa-linkedin-square icon"></i></a>
          </div>
        </div>
      </div>
    );
  }
}

export default Introduction