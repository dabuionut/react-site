import React, { Component } from 'react';

class Sun extends Component {
  render() {
    return (
      <div className="sun-layer">
        <div className="sun">
        </div>
        <div className="sun-2">
        </div>
      </div>
    );
  }
}