import Footer from './Footer'
import Section from './Section'
import Header from './Header'
import Hills from './Hills'
import Sun from './Sun'
import Introduction from './Introduction'

export {

	Footer,
	Section,
	Header,
	Hills,
	Sun,
	Introduction
}